

class TelegramMonitor:
    def __init__(self) -> None:
        # TODO: init keywords and channel names into class fields
        pass


    def run() -> None:
        # get all new mesages from channels

        # forward the ones that contain keywords to user
        return None;